<?php

require 'vendor/autoload.php'; 
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

use FireBird\FireBird;

try {
    $projectId = $_ENV['PROJECT_ID'];
    $apiUrl = $_ENV['API_URL'];
    $fireBird = new FireBird($projectId, $apiUrl);

   /* $fireBird->setFirstName('John');
    $fireBird->setLastName('Doe');
    $fireBird->setUsername('johndoe');
    $fireBird->setGender('Male');
    $fireBird->setMobileNumber('9999966666655555555555');
    $fireBird->setBirthDate('1990-01-01');
    $fireBird->setEmail('john.doe@example.com');
    $fireBird->setAddress('123 Main St');
    $fireBird->setWhatsappNumber('0987654321');
    $fireBird->setLocation('New York');
    $fireBird->setCity('New York City');
    $fireBird->setState('NY');
    $fireBird->setDistrict('Manhattan');
    $fireBird->setUserAttribute('address', 'mohali', 'String');*/

    $response = $fireBird->execute();
    print_r($response);
} catch (\Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
